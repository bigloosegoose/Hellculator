#version 330 core
out vec4 FragColor;

in vec2 TexCoords;

void main()
{
	FragColor = vec4(0.4,0.4,0.4,1.0);
}